# cmpsc431w-fa25-project-f-f
cmpsc431w-fa25-project-f-f created by GitHub Classroom

Created for a CMPSC 431W group project

Update [9/12/2025]:
A team of two people: Fatmah Almeer and Filzah Shamshudin
Initial and general project idea: Free Food Map



Update [12/7/2025]:


Free Food Map Application
Using Python: Flask, and PostgreSQL

**Overview:**

The Free Food map is a database designed to help organizations, volunteers, and community members manage and locate free food resources.


**Key Features:**

(1) Public Users:
  - Search free food locations by ZIP code
  - Submit a new location suggestion
  - Report an issue about a location

(2) Volunteers:
  - View upcoming events
  - Sign up for events
  - View their registered events

(3) Organization Staff:
  - Dashboard showing their organization’s data
  - View/manage their locations
  - View/manage reports for their locations
  - View events hosted by their organization

(4) Administrators:
  - Approve or reject contributor registration requests
  - Full user management (edit/delete users)
  - Organization management (create/edit/delete)
  - Event management (create/edit/delete)
  - Location management
  - Review/approve/reject location suggestions
  - View/resolve/delete reports
