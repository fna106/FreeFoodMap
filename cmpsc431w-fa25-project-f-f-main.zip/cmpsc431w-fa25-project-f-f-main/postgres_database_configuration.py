import psycopg2

def get_db_connection():
    return psycopg2.connect(
        host="localhost",
        database="postgres",
        user="postgres",
        password=219260,
        port=5432
    )

